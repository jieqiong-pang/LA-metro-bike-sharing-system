Dear LLNCS user,

The files in this directory belong to the LaTeX2e package for
Lecture Notes in Computer Science (LNCS) of Springer-Verlag.

It consists of the following files:

  readme.txt                this file

  history.txt               the version history of the package

  llncs.cls                 the LaTeX2e document class

  Bike Sharing.tex          project paper

  /Images/region.png        a figure used in the project paper
  /Images/station.png       a figure used in the project paper

  llncsdoc.pdf              the documentation of the class (PDF version)

  splncs04.bst              current LNCS BibTeX style with alphabetic sorting

 DSCI554_project_           the documentation of the class (PDF version)
